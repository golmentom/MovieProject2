package com.example.movieprojectstage2_2021_10_18vesrion5;
import android.content.AsyncTaskLoader;
import android.content.Context;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.List;
// ==Aa.1 Rozszerzamy naszą klasę o  AsyncTaskLoader
public class ReviewTrailerLoaderClass extends AsyncTaskLoader<List<ReviewTrailerClass>> {

    // == Aa.1.1 Definiujemy zmienną url dla adresu url
    private String mUrl;
    // ==Aa.2 Definiujemy sobie konstruktor klasy.
    public ReviewTrailerLoaderClass(@NonNull Context context, String url) {
        super(context);
        mUrl = url;

    }

    // == Aa.3 Nadpisujemy sobie metodą loadInBackground
    @Nullable
    @Override
    public List<ReviewTrailerClass> loadInBackground() {
        List <ReviewTrailerClass> results = null;
        if(mUrl == null){
            Log.e("loadInBackground","+++++++++++++++++loadInBackground+++++: " + mUrl +"\n");
            return null;
        }
        // ==Aa.3.1 chcemy aby nasz if wybierał odpowiednią metodę przechwytywania danych w zależności od tego czy pobiera reviews czy trailers
        // ==Aa.3.2 Robimy to na podstawie sładu adresu URL
        if(mUrl.contains("reviews")){
            results = QueryUtilsClass.fetchReviewsData(mUrl);
        }
        if(mUrl.contains("videos")){
            results = QueryUtilsClass.fetchTrailersData(mUrl);
        }
        return results;
    }
// == Aa.4 nadpisujemy metodę onStartLoading

    @Override
    protected void onStartLoading() {
        forceLoad();
    }
}
