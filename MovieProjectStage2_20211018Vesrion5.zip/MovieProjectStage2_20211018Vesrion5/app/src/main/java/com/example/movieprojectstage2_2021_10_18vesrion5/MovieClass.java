package com.example.movieprojectstage2_2021_10_18vesrion5;

public class MovieClass {

    //Zmienne
    private String mTitle;
    private String mPoster;
    private String mOverview;
    private String mReleaseDate;
    private double mRating;
    private double mVoteEverage;
    private String mTrailerUrl;
    private String mReviewUrl;

    public MovieClass(String title, String poster, String overview, String releaseDate, double rating, double voteEverage, String trailerUrl, String reviewUrl){
        mTitle = title;
        mPoster = poster;
        mOverview = overview;
        mReleaseDate = releaseDate;
        mRating = rating;
        mVoteEverage = voteEverage;
        mTrailerUrl = trailerUrl;
        mReviewUrl = reviewUrl;
    }
    // definiujemy getters
    public String getmTitle(){return mTitle;}
    public String getmPoster(){return mPoster;}
    public String getmOverview(){return mOverview;}
    public String getmReleaseDate(){return mReleaseDate;}
    public double getmRating(){return mRating;}
    public double getmVoteEverage(){return mVoteEverage;}
    public String getmTrailerUrl(){return mTrailerUrl;}
    public String getmReviewUrl(){return mReviewUrl;}
    //definuijemy setters choc na razie niebeda potrzebne
    public void setmTitle(String title){mTitle = title;}
    public void setmPoster(String poster){mPoster = poster;}
    public void setmOverview(String overview){mOverview = overview;}
    public void setmReleaseDate(String releaseDate){mReleaseDate =releaseDate;}
    public void setmRating(double rating){mRating = rating;}
    public void setmVoteEverage(double voteEverage){mVoteEverage =voteEverage;}
    public void setmTrailerUrl(String trailerUrl){mTrailerUrl = trailerUrl;}
    public void setmReviewUrl(String reviewUrl){mReviewUrl = reviewUrl;}
}
