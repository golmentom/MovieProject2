package com.example.movieprojectstage2_2021_10_18vesrion5;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.app.LoaderManager;
import android.content.Context;
import android.content.Intent;
import android.content.Loader;
//import android.graphics.Movie;
//import android.net.Network;
//import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
//import android.widget.GridLayout;
import android.widget.TextView;
//import android.widget.Toast;
import java.util.ArrayList;
import java.util.List;

import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements LoaderManager.LoaderCallbacks<List<MovieClass>>, MovieAdapter.MovieListItemClickListener{

    private MovieAdapter mMovieAdapter;
    private RecyclerView mRecyclerView;
    public final ArrayList<MovieClass> movies  = new ArrayList<>();
    private int mMovieListItemNo;

    TextView mSortingTypeMainActTextView;

    private static final String BASE_THEMOVIEDB_RESPONSE_POP = "http://api.themoviedb.org/3/movie/popular?api_key=abbae3d0823ab61a85718da3d554f6ad";
    private static final String BASE_THEMOVIEDB_RESPONSE_TOP_R = "http://api.themoviedb.org/3/movie/top_rated?api_key=abbae3d0823ab61a85718da3d554f6ad";

    private static final int MOVIE_LOADER_ID_POP = 1;
    private static final int MOVIE_LOADER_ID_TOP_R = 2;

    TextView mMovieEmptyState;

    private int currentLoaderID = 1;
    //Dodane na potrzebe testow 06.11
   // private MovieAppDatabase movieDb;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mMovieEmptyState = findViewById(R.id.emptyStateTextV);
       /// Dodane do testow 06.11
     //   movieDb = MovieAppDatabase.getInstance(getApplicationContext());

        ConnectivityManager connManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);

        NetworkInfo networkInfo = connManager.getActiveNetworkInfo();

        if(networkInfo != null && networkInfo.isConnected()){
            LoaderManager loaderManager = getLoaderManager();
            loaderManager.initLoader(MOVIE_LOADER_ID_POP, null, this);
        }else{

            View loadingIndicator = findViewById(R.id.loadingIndicator);
            loadingIndicator.setVisibility(View.GONE);
            mMovieEmptyState.setText(R.string.noInternetStr);
        }

        mMovieListItemNo = movies.size();

        mRecyclerView = (RecyclerView) findViewById(R.id.recyclerViewMovies);

        GridLayoutManager layoutManager = new GridLayoutManager(this,2);

        mRecyclerView.setLayoutManager(layoutManager);
        mRecyclerView.setHasFixedSize(true);
        mMovieAdapter = new MovieAdapter(this, movies, mMovieListItemNo,this);
        mRecyclerView.setAdapter(mMovieAdapter);

    }

    @Override
    public void onListItemClick(int clickedIntemIndex, MovieClass clickedMovie) {
        Intent detailActivityIntent = new Intent(this, DetailActivity.class);
        detailActivityIntent.putExtra("title", clickedMovie.getmTitle());
        detailActivityIntent.putExtra("overview", clickedMovie.getmOverview());
        detailActivityIntent.putExtra("photoid", clickedMovie.getmPoster());
        detailActivityIntent.putExtra("rating",Double.toString(clickedMovie.getmRating()));
        detailActivityIntent.putExtra("voteEverage", Double.toString(clickedMovie.getmVoteEverage()));
        detailActivityIntent.putExtra("release_date", clickedMovie.getmReleaseDate());
        detailActivityIntent.putExtra("trailerUrl", clickedMovie.getmTrailerUrl());
        detailActivityIntent.putExtra("reviewUrl",clickedMovie.getmReviewUrl());
        startActivity(detailActivityIntent);

    }

    @Override
    public Loader<List<MovieClass>> onCreateLoader(int id, Bundle args) {

        String urlString = "";

        if(currentLoaderID == 1){
            urlString = BASE_THEMOVIEDB_RESPONSE_POP;
        }
        if(currentLoaderID == 2){
            urlString = BASE_THEMOVIEDB_RESPONSE_TOP_R;
        }
        return new MovieLoaderClass(this, urlString);
    }

    @Override
    public void onLoadFinished(Loader<List<MovieClass>> loader, List<MovieClass> movieResult) {
        View loadingIndicatorMainAct = findViewById(R.id.loadingIndicator);
        loadingIndicatorMainAct.setVisibility(View.GONE);
        Log.e("onLoadFinished","======================++++++++++++++++ Enter to onLoadFinished++++++++++++");
        movies.clear();
        if (movieResult != null && !movieResult.isEmpty()) {
            movies.addAll(movieResult);
            Log.e("onLoadFinished","++++++++++++++++ Enter to onLoadFinished++++++++++++");
        }
        mMovieAdapter.notifyDataSetChanged();
    }

    @Override
    public void onLoaderReset(Loader<List<MovieClass>> loader) {
        movies.clear();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater =getMenuInflater();
        inflater.inflate(R.menu.settings_menu, menu);
        return true;
    }


    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();
        if(id == R.id.menuItemMostPopularMovie){
            currentLoaderID = 1;
            LoaderManager loaderManager = getLoaderManager();
            loaderManager.initLoader(MOVIE_LOADER_ID_POP, null, this);
            return true;
        }
        if(id == R.id.menuItemTopRatedMovie){
            currentLoaderID = 2;
            LoaderManager loaderManager = getLoaderManager();
            loaderManager.initLoader(MOVIE_LOADER_ID_TOP_R, null, this);
            return true;
        }
        if(id == R.id.menuItemFavouriteDataB){
            Toast.makeText(getApplicationContext(), "Favourite was Clicked",Toast.LENGTH_SHORT).show();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

}