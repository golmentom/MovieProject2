package com.example.movieprojectstage2_2021_10_18vesrion5;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import android.content.Context;
import android.util.Log;

//== F.0 Tworzymy klasę w której Tworzymy naszą bazę danych
//== F.0 Po tym jak utworzyliśmy już Entity i Dao
//==F.1 Po utworzeniu pliku klasy dodajemy abstract i rozszerzamy ją o RoomDatabase
//==F.4 Dodajemy dane bazy adnotacje
@Database(entities = {MovieEntryClass.class}, version = 1, exportSchema = false)
public abstract class MovieAppDatabase extends RoomDatabase {
// == F.2 Definiujemy zmienne
    private static final Object LOCK = new Object();
    private static final String DATABASE_NAME = "movieList";
    private static MovieAppDatabase sInstance;
//== F.3 Tworzymy naszą baze danych jeśli sInstance ==null
//==F.3 lub jeśli istnieje Baza danych jest
    public static MovieAppDatabase getInstance(Context context){
        Log.d("MovieAppDataBase", "======Przed Pentlą sInstance======");
        if(sInstance == null){
            synchronized(LOCK){
                Log.d("MovieAppDataBase", "=========Creating new database instance=========");
                //==G.1 aby przetestować naszą baze danych umożliwiamy  na razie uruchamianie jej w głównym wątku
                //==G.1 dodajemy czasowo na końcu  .allowMainThreadQueries() . DO USUNIECIA POTEM
                sInstance = Room.databaseBuilder(context.getApplicationContext(),MovieAppDatabase.class, MovieAppDatabase.DATABASE_NAME).allowMainThreadQueries().build();
            }
        }
        Log.d("MovieAppDatabase", "Getting the database instance");
   //==F.3.1 Zwracamy nowo utworzaoną lub podłączoną istniejącą instancję klasy.
        return sInstance;
       // return null;
    }
    public abstract MovieDao movieDao();
}
