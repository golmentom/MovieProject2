package com.example.movieprojectstage2_2021_10_18vesrion5;
import android.content.AsyncTaskLoader;
import android.content.Context;
import android.util.Log;
import java.util.List;


public class MovieLoaderClass extends AsyncTaskLoader<List<MovieClass>> {

    private String mUrl;
    public MovieLoaderClass(Context context, String url){
        super(context);
        mUrl = url;

    }

    @Override
    public List<MovieClass> loadInBackground() {
        if (mUrl == null) {
            Log.e("loadInBackground", "+++++++++++++++++loadInBackground+++++: " + mUrl + "\n");
            return null;
        }
        List<MovieClass> results = QueryUtilsClass.fetchMovieData(mUrl);
        return results;
    }

    @Override
    protected void onStartLoading() {
        forceLoad();
    }

}
