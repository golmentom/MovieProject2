package com.example.movieprojectstage2_2021_10_18vesrion5;
import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class MovieAdapter extends RecyclerView.Adapter<MovieAdapter.MovieViewHolder> {

    private int mNumberOfItems;
    private ArrayList<MovieClass> mMovieList;
    Context mContext;

    final private MovieListItemClickListener mMovieClickListener;

    public MovieAdapter(Context context, ArrayList<MovieClass> movieList, int numberOfItems, MovieListItemClickListener listener){
        mContext = context;
        mMovieList = movieList;
        mNumberOfItems = numberOfItems;
        mMovieClickListener =listener;
    }

    public class MovieViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener{

        TextView mTitleTextView;
        ImageView mImageView;

        public MovieViewHolder(@NonNull View itemView) {
            super(itemView);

            mTitleTextView= (TextView) itemView.findViewById(R.id.titleTextViewId);
            mImageView = (ImageView) itemView.findViewById(R.id.posterImabeViewId);
                      itemView.setOnClickListener(this);
        }
               @Override
        public void onClick(View v) {
            int clickedPosition = getAbsoluteAdapterPosition();
            MovieClass currentMovie = mMovieList.get(clickedPosition);
            mMovieClickListener.onListItemClick(clickedPosition,currentMovie);
        }


    }

    @NonNull
    @Override
       public MovieViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        Context context = parent.getContext();
        int layoutIdForListItem = R.layout.items_list_view;
        LayoutInflater inflater = LayoutInflater.from(context);
        Boolean shouldAttachedToParentImmidietly = false;
        View view = inflater.inflate(layoutIdForListItem,parent,shouldAttachedToParentImmidietly);
        MovieViewHolder viewHolder = new MovieViewHolder(view);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull MovieViewHolder holder, int position) {
        MovieClass currentMovie = mMovieList.get(position);
        holder.mTitleTextView.setText(currentMovie.getmTitle());
        Log.e("onBind_ViewHolder","++++++++++++++++++onBindViewHolder String currentMovie.getmPoster()+++++: " + currentMovie.getmTitle() +"\n");
        String urlString = currentMovie.getmPoster();
        Log.e("onBind_ViewHolder","++++++++++++++++++onBindViewHolder String currentMovie.getmPoster()+++++: " + urlString +"\n");
        Picasso.with(mContext).load(currentMovie.getmPoster()).into(holder.mImageView);
    }

    @Override
    public int getItemCount() {
        return mMovieList.size();
    }

     public interface MovieListItemClickListener{

        void onListItemClick(int clickedIntemIndex, MovieClass clickedMovie);
    }

}
