package com.example.movieprojectstage2_2021_10_18vesrion5;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;
//== E.0 Utworzyliśmy nowy interfejs Movie Dao
//== E.1 Tworzymy Metody implementujące wymianę danych z naszym interfejsem
//== E.1 Insert, Delete, upDate, Query
@Dao
public interface MovieDao {
    @Query("SELECT * FROM moviesTable ORDER BY title")
    List<MovieEntryClass> loadAllTasks();

    @Insert
    void insertMovies(MovieEntryClass movieEntry);

    @Update(onConflict = OnConflictStrategy.REPLACE)
    void updateMovies(MovieEntryClass movieEntry);

    @Delete
    void deleteMovies(MovieEntryClass movieEntry);
}
