package com.example.movieprojectstage2_2021_10_18vesrion5;

import android.text.TextUtils;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;

public class QueryUtilsClass {
    //G.1 Tworzymy konstruktor klasy, która będzie pobierała dane z internetu.
    public QueryUtilsClass(){}

    //G.2 Tworzymy metodę tworzącą adres URL
    private static URL createUrl(String urlString){
        URL url = null;
        try{
            url = new URL(urlString);
        }catch (MalformedURLException e){
            Log.e("createUrl method", "MalformedUrlException: " +e);
        }
        return url;
    }
    //G.3 Tworzymy metodę która odczytuje dane ze stremu i buforuje dane
    private static String readFromStream(InputStream inputStream) throws IOException{
        //G.3.1 Budujemy string buildera
        StringBuilder stringBuilder = new StringBuilder();
        if(inputStream != null){
            InputStreamReader streamReader = new InputStreamReader(inputStream, Charset.forName("UTF-8"));
            BufferedReader bufferedReader = new BufferedReader(streamReader);
            String line = bufferedReader.readLine();
            while(line != null){
                stringBuilder.append(line);
                line = bufferedReader.readLine();
            }
        }
        return stringBuilder.toString();
    }

    //G.4 Tworzymy połączenie HTTP i odwołujemy się do  odczytu danych ze strumienia metoda powyżej

    private static String makeHttpResponse(URL url) throws IOException{
        //G.4.1 Tworzymy string który będzie zbierał wszystkiedane i inicjujemy początkową wartością
        String jsonString = "";
        if(url == null){
            return jsonString;
        }

        HttpURLConnection urlConnection = null;
        InputStream inputStream = null;

        try{
            //G.4.2 Zestawiamy połączenie http
            urlConnection = (HttpURLConnection) url.openConnection();
            urlConnection.setReadTimeout(10000);
            urlConnection.setConnectTimeout(15000);
            urlConnection.setRequestMethod("GET");
            urlConnection.connect();
            //G.4.3 pobieramy dane
            if(urlConnection.getResponseCode() == 200){
                inputStream = urlConnection.getInputStream();
                jsonString = readFromStream(inputStream);
            }else{
                Log.e("makeHttpResponse Method", "Problem with response code: " + urlConnection.getResponseCode());
            }
        }catch (IOException e){
            Log.e("makeHttpResponse Method", "IOException: " + e);
        }finally {
            //G.4.4 Zamykamy połączenie i strumień i zwracamy wartośc
            if(urlConnection != null){ urlConnection.disconnect();}
            if(inputStream != null){ inputStream.close();}
        }
        return jsonString;
    }
    //G.5 Tworzymy funkcję rozpakowującą dane z JSON

    private static ArrayList extractFeatureFromJson(String jsonMovie){

        //G.5.1 sprawdzamy czy jsonString nie jest pusty
        if(TextUtils.isEmpty(jsonMovie)){return null;}
        //G.5.2 Tworzymy liste do przechowywania danych
        ArrayList<MovieClass> movies = new ArrayList<>();
        try{
            //G.5.3 Rozpoczynamy parsing
            JSONObject rootMovie = new JSONObject(jsonMovie);
            JSONArray resultsArra = rootMovie.getJSONArray("results");
            for(int i = 0; i < resultsArra.length(); i++){
                JSONObject currentMovieObj = resultsArra.getJSONObject(i);
                String movieId = currentMovieObj.getString("id");
                String orginalTitle = currentMovieObj.getString("original_title");
                String overview = currentMovieObj.getString("overview");
                double rating = currentMovieObj.getDouble("popularity");
                double voteAverage = currentMovieObj.getDouble("vote_average");
                String releaseDate =currentMovieObj.getString("release_date");
                String poster = currentMovieObj.getString("poster_path");
                String posterLink = "http://image.tmdb.org/t/p/w500" + poster;
                String movieLink = "https://api.themoviedb.org/3/movie/" + movieId + "/videos?api_key=abbae3d0823ab61a85718da3d554f6ad";
                String reviewLink = "https://api.themoviedb.org/3/movie/" + movieId + "/reviews?api_key=abbae3d0823ab61a85718da3d554f6ad";
                Log.e("extractFeatureFromJson method", "revieweLink " + i + "=====" + reviewLink);
                MovieClass currentMovie = new MovieClass(orginalTitle, posterLink, overview, releaseDate, rating, voteAverage, movieLink, reviewLink);
                movies.add(currentMovie);
            }

        } catch (JSONException e) {
            Log.e("extractFeatureFromJson method", "JSON Exception problem with Parcing " + e);
        }
        return movies;
    }

    //G.6 metoda łączaca wszystkie poprzednie
    public static List<MovieClass> fetchMovieData(String urlString){
        URL url =createUrl(urlString);
        String jsonString = null;
        try {
            //G.6.1 Dodajemy  Poniższą linię aby wydłużyć czas sciagania danych. +InterruptedException
            Thread.sleep(2000);
            jsonString = makeHttpResponse(url);
        } catch (IOException e) {
            Log.e("fetchMovieData method", "IOException: " + e);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        List<MovieClass> movies = extractFeatureFromJson(jsonString);
        return movies;
    }
    //G.6 =========Koniec Metod dla MainActivity=============
    // Y.1 Definiujemy metody dla traials zaczynajac od rozpakowania danych z JSON
    private static ArrayList extractFeatureFromTraialsJson(String jsonMovieTraials){
        // Y.1.1 sprawdzamy czy nasz JsonString nie jest pusty
        if(TextUtils.isEmpty(jsonMovieTraials)){
            return null;
        }
        // Y.1.2 definiujemy liste klas
        ArrayList<ReviewTrailerClass> trailers = new ArrayList<>();
        // Y.1.3 rozpakowujemy dane
        try{
            JSONObject rootMovieTrailer = new JSONObject(jsonMovieTraials);
            JSONArray resultsArrayTrailer = rootMovieTrailer.getJSONArray("results");
            for(int i = 0; i<resultsArrayTrailer.length(); i++){
                JSONObject currentTraialObject = resultsArrayTrailer.getJSONObject(i);
                String key = currentTraialObject.getString("key");
                String trailerName = currentTraialObject.getString("name");
                String trailerLink = "https://www.youtube.com/watch?v=" + key;
                ReviewTrailerClass currentReviewTrailer = new ReviewTrailerClass(key,trailerName,trailerLink);
                // Y.1.4 dodajemy kolejne klasy do listy
                trailers.add(currentReviewTrailer);
            }
        }catch (JSONException e){
            Log.e("extractFeatureFromTrailerJson method", "JSON Exception problem with Parcing " + e);
        }
        return trailers;
    }
    // Y.2 Definiujemy metodę, która będzie rozpakowywanie z Json buforowanie stringów i tworzenie URL
    // Y.2 metody createUrl, makeHttpResponse wykorzystamy bez zmian (te z których korzystalismy w MainActivty.
    public static List<ReviewTrailerClass> fetchTrailersData(String urlString){
        URL url =createUrl(urlString);
        String jsonString = null;
        try {
            Thread.sleep(100);
            jsonString = makeHttpResponse(url);
        }catch (IOException e){
            Log.e("fetchMovieData method", "IOException: " + e);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        List<ReviewTrailerClass> trailers = extractFeatureFromTraialsJson(jsonString);
        return trailers;
    }
    // Y.3 Dodajemy Metody dla Reviews. Tak jak w traials
// Y.3 zaczynamy od rozpakowania danych Json
    private static ArrayList extractFeatureFromReviewsJson(String jsonReview){
// Y.3.1 Sprawdzamy czy json nie jest puste
        if(TextUtils.isEmpty(jsonReview)){
            return null;
        }

// Y.3.2 Definiujemy sobie liste gdzie będą zapisywane wyniki
        ArrayList<ReviewTrailerClass> reviews = new ArrayList<>();
// Y.3.3 robimy parsing danych
        try{
            JSONObject rootReview = new JSONObject(jsonReview);
            JSONArray resultsArrayReviews = rootReview.getJSONArray("results");
            for(int i =0; i < resultsArrayReviews.length(); i++){
                JSONObject currentReviewObject = resultsArrayReviews.getJSONObject(i);
                String authorReview = currentReviewObject.getString("author");
                String contentReview = currentReviewObject.getString("content");
                String reviewLink = currentReviewObject.getString("url");
                ReviewTrailerClass currentReview = new ReviewTrailerClass(authorReview,contentReview,reviewLink);
                reviews.add(currentReview);
            }
        } catch (JSONException e) {
            Log.e("extractFeatureFromReviewJson method", "JSON Exception problem with Parcing " + e);
        }
        return reviews;
    }
    public static List<ReviewTrailerClass> fetchReviewsData(String urlString){
        URL url = createUrl(urlString);
        String jsonString = null;
        try{
            Thread.sleep(100);
            jsonString = makeHttpResponse(url);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }catch (IOException e){
            Log.e("fetchReviewsData method", "IOException: " + e);
        }
        List<ReviewTrailerClass> reviews = extractFeatureFromReviewsJson(jsonString);
        return reviews;
    }

}
