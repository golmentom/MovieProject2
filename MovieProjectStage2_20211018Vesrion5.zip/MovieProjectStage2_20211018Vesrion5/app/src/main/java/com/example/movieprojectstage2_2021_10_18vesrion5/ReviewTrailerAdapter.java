package com.example.movieprojectstage2_2021_10_18vesrion5;
import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

// Z.1 Zaczynamy od zbudowania adaptera dla review i trailers.
public class ReviewTrailerAdapter extends RecyclerView.Adapter<ReviewTrailerAdapter.TrailerViewHolder> {
    // Z.2 Definiujemy niezbędne zmienne tak jak miało to miejsce w MovieAdapterze
    private int mNumberOfItems;
    private ArrayList<ReviewTrailerClass> mTrailerList;
    Context mContext;
    // Z.2.X ta zmienna musi być dodana dopiero jak zdefiniujemy Click listenera
    final private TrailerListItemClickListener mTrailerClickListener;
    //==Ff.2 Krok 1 został zdefiniowany w Detaila Activity Ff.1.x
    boolean mHasePlayImage;

    // Z.2. Tworzymy konstruktor klasy
    // F.f.2 Dodajemy zmienną boolean do konstruktora adaptera.
    public ReviewTrailerAdapter(Context context, ArrayList<ReviewTrailerClass> trailerList, int numberOfItems, DetailActivity listener, boolean hasPlayImage){
        mContext = context;
        mTrailerList = trailerList;
        mNumberOfItems = numberOfItems;
        mTrailerClickListener = (TrailerListItemClickListener) listener;
        mHasePlayImage = hasPlayImage;
    }
    // Z.5 Definiujemy sobie metody dla naszego recycler View2
    @NonNull
    @Override
    public ReviewTrailerAdapter.TrailerViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        Context context = parent.getContext();
        int layoutIdForListItem = R.layout.trailers_list_item;
        LayoutInflater inflater = LayoutInflater.from(context);
        Boolean shouldAttachedToParentImmidietly = false;
        View view = inflater.inflate(layoutIdForListItem, parent, shouldAttachedToParentImmidietly);
        ReviewTrailerAdapter.TrailerViewHolder viewHolder = new ReviewTrailerAdapter.TrailerViewHolder(view);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(ReviewTrailerAdapter.TrailerViewHolder holder, int position) {
        ReviewTrailerClass currentTrailer = mTrailerList.get(position);
        //==Ff.4 Tworzymy sobie ifa w View holderze, który decyduje czy
        //==Ff.4 strzałka ma byc howana czy nie
        if(mHasePlayImage == true){
            holder.mPlayArrowImage.setVisibility(View.VISIBLE);
            Log.e("onBind_ViewHolder","======== onBind_ViewHolder========= Enter to setVisibility VISIBLE"+ mHasePlayImage);
        }
        if(mHasePlayImage == false){ holder.mPlayArrowImage.setVisibility(View.GONE);}
        Log.e("onBind_ViewHolder","======== onBind_ViewHolder========= Enter to setVisibility GONE"+ mHasePlayImage);
        holder.mTrailerTitleTextView.setText(currentTrailer.getmTrailerNameReviewContent());
        Log.e("onBind_ViewHolder", "++++++++++++++++++onBindViewHolder String currentMovie.getmPoster()+++++: " + currentTrailer.getmKeyAuthor()+ "\n");
    }

    @Override
    public int getItemCount() {
        return mTrailerList.size();
    }

    // Z.3 definiujemy sobie tera publiczna klasę dla ViewHoldera, który będzie przechowywał odwpłania dla naszych
    // Z.3 widoków ale zanim to nastąpi musimy zdefiniować najpierw w pliku trailers_list_item.xml nowy kontener z widokami.

    public class TrailerViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener{
        // Z.3.1 Tworzymy sobie instancję widokó które będziemy wyświetlać
        TextView mTrailerTitleTextView;
        //==Ff.3 W ViewHolderze dodajemy sobie zmienną która przechowuje  naszą strzałkę oddtwarzania.
        ImageView mPlayArrowImage;
        // Z.3.2 Nadpisujemy sobie konstruktor
        public TrailerViewHolder(@NonNull View itemView) {
            super(itemView);

            //Z.3.3 Tworzymy instancję naszego widoku. UWAGA!!!!: Pamiętaj, że aby
            //Z.3.3 Wskazać na odpowiednie Id to najpierw trzeba sobie utworzyć plik xml z naszym kontenerem
            mTrailerTitleTextView = (TextView) itemView.findViewById(R.id.titleTrailerTextViewId);
            //==Ff.3.1 Twprzymy sobie odwzorowanie do strzełki
            mPlayArrowImage = (ImageView) itemView.findViewById(R.id.imageTrailerImageViewId);
            itemView.setOnClickListener(this);
        }
        // Z.3.4 Nadpisujemy sobie funkcję onClick
        @Override
        public void onClick(View v) {
            int clickedPosition = getAbsoluteAdapterPosition();
            ReviewTrailerClass currentTrailer = mTrailerList.get(clickedPosition);
// Z.3.4 Najpierw musimy sobie zdefiniować funkcję onListItemClicked  krok Z.4
            mTrailerClickListener.onListItemClick(clickedPosition, currentTrailer);

        }
    }
    // Z.4 definiujemy sobie publiczny interfejs, który będzie nam obsługiwał klikanie
    public interface TrailerListItemClickListener{
        // Z.4.1 Definiujemy sobie nasz interfejs
        void onListItemClick(int clickedPosition, ReviewTrailerClass clickedTrailer);
    }
}
