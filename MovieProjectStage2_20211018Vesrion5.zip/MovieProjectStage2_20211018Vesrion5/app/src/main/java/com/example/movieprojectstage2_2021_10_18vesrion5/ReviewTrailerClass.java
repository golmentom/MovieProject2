package com.example.movieprojectstage2_2021_10_18vesrion5;

public class ReviewTrailerClass {
    // X.1 Zmienne Klasy będą przyechowywały jedną z 2 wartosci w zaleznosci od tego czybedzie wyswietlany
    // X.1 Review czy  trailer list na przykład keyAutor albo
    // X.1 trailer link lub Review Link
    // X.1 i tak zaczynamy od utworzenia zmiennych
    private String mKeyAuthor;
    private String mTrailerNameReviewContent;
    private String mTrailerReviewLink;

    // X.2 Definiujemy konstruktor Klasy
    public ReviewTrailerClass(String keyAuthor, String trailerNameReviewContent, String trailerReviewLink){
        mKeyAuthor = keyAuthor;
        mTrailerNameReviewContent = trailerNameReviewContent;
        mTrailerReviewLink = trailerReviewLink;
    }
    // X.3 budujemy Gethers
    public String getmKeyAuthor(){return mKeyAuthor;}
    public String getmTrailerNameReviewContent(){return mTrailerNameReviewContent;}
    public String getmTrailerReviewLink(){return mTrailerReviewLink;}
    // X.4 buduję Setters
    public void setmKeyAuthor(String keyAuthor) {mKeyAuthor = keyAuthor;}
    public void setmTrailerNameReviewContent(String trailerNameReviewContent){mTrailerNameReviewContent = trailerNameReviewContent;}
    public void setmTrailerReviewLink(String trailerReviewLink){mTrailerReviewLink =trailerReviewLink;}
}
