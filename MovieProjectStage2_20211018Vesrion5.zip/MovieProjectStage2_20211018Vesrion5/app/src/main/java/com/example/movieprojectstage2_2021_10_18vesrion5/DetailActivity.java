package com.example.movieprojectstage2_2021_10_18vesrion5;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.LoaderManager;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.Loader;
//import android.app.LoaderManager.LoaderCallbacks;
//import android.media.Image;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.List;


public class DetailActivity extends AppCompatActivity implements LoaderManager.LoaderCallbacks<List<ReviewTrailerClass>>, ReviewTrailerAdapter.TrailerListItemClickListener {
    TextView mTitleDetailActTextV;
    TextView mOverviewDetailActTextV;
    ImageView mPosterDetailActImageV;
    TextView mReleaseDateDetailActTextV;
    TextView mRatingDetailActTextV;
    TextView mVoteEverageDetailActTextV;
    //==B.1 Tworzymy zmienną dla Widoku Favourite.
    ImageView mFavouriteImageView;
    RadioButton trailerButton;
    RadioButton reviewsButton;
    RadioGroup dataDetailActRadioGroup;
    String title;
    String overview;
    String rating;
    String releaseDate;
    String photoid;
    String voteEverage;
    String trailerUrl;
    String reviewUrl;
    //== B.2 definiujemy zmienną booleanf Favourite Clicked i inicjujemy ją
    //==B.2 Zmienna ta będzie zmieniała wartość w zależności od tego czy  kliknięto  w widok czy nie
    boolean favouriteClicked = false;

    private ReviewTrailerAdapter mReviewTrailerAdapter;
    private RecyclerView mRecyclerView;
    private TextView mTrailerEmptyState;
    private static final int TRAILER_LOADER_ID = 3;
    private static final int REVIEW_LOADER_ID = 4;
    private int mTrailerListItemNo;
    public final ArrayList<ReviewTrailerClass> reviewTrailers = new ArrayList<>();
    String dataUrl;
    //== H.1 Definiujemy zmienną dla naszej bazy danych.
    private MovieAppDatabase movieDb;
    private static boolean HAS_IMAGE = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);
        mTitleDetailActTextV = (TextView) findViewById(R.id.titleIdDetailActivity);
        mOverviewDetailActTextV = (TextView) findViewById(R.id.overviewIdDetailActivity);
        mPosterDetailActImageV = (ImageView) findViewById(R.id.posterIdDetailActivity);
        mReleaseDateDetailActTextV = (TextView) findViewById(R.id.releaseDateIdDetailActivity);
        mRatingDetailActTextV = (TextView) findViewById(R.id.ratingIdDetailActivity);
        mVoteEverageDetailActTextV = (TextView) findViewById(R.id.voteEverageIdDetailActivity);
        trailerButton = (RadioButton) findViewById(R.id.trailersRadioButDetailActivity);
        reviewsButton = (RadioButton) findViewById(R.id.reviewsRadioButDetailActivity);
        dataDetailActRadioGroup = (RadioGroup) findViewById(R.id.optionsGroup);
        //==B.3 dokonujemy castingu na zmienną  mFavouriteImageView.
        mFavouriteImageView = (ImageView) findViewById(R.id.favouriteImageDetailActivity);


        Intent intentThatStartedDetailAct = getIntent();

        if(intentThatStartedDetailAct.hasExtra("title")){
            title = intentThatStartedDetailAct.getStringExtra("title");
        }
        if(intentThatStartedDetailAct.hasExtra("overview")){
            overview = intentThatStartedDetailAct.getStringExtra("overview");
        }
        if(intentThatStartedDetailAct.hasExtra("photoid")){
            photoid = intentThatStartedDetailAct.getStringExtra("photoid");
            Picasso.with(DetailActivity.this).load(photoid).into(mPosterDetailActImageV);
        }
        if(intentThatStartedDetailAct.hasExtra("rating")){
            rating =intentThatStartedDetailAct.getStringExtra("rating");
        }
        if(intentThatStartedDetailAct.hasExtra("release_date")){
            releaseDate = intentThatStartedDetailAct.getStringExtra("release_date");
        }
        if(intentThatStartedDetailAct.hasExtra("voteEverage")){
            voteEverage = intentThatStartedDetailAct.getStringExtra("voteEverage");
        }
        if(intentThatStartedDetailAct.hasExtra("trailerUrl")){
            trailerUrl = intentThatStartedDetailAct.getStringExtra("trailerUrl");
        }
        if(intentThatStartedDetailAct.hasExtra("reviewUrl")){
            reviewUrl = intentThatStartedDetailAct.getStringExtra("reviewUrl");
        }

        mTitleDetailActTextV.setText(title);
        mOverviewDetailActTextV.setText(overview);
        mReleaseDateDetailActTextV. setText(releaseDate);
        mRatingDetailActTextV.setText(rating);
        mVoteEverageDetailActTextV.setText(voteEverage);

        // ==B.4 Definiujemy dla widoku onClickListeneraa i w zależności od wartości
        // ==B.4 Zmiennej mFavouriteClicked ustawiamy odpowiedni obrazek (ostatni krok zmian w tej sekcji
        //==H.2 Dokonujemy inicjalizacji naszej bazy danych.
        movieDb = MovieAppDatabase.getInstance(getApplicationContext());
        mFavouriteImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if(favouriteClicked == false){
                    favouriteClicked = true;
                    mFavouriteImageView.setImageResource(R.drawable.outline_favorite_black_24);
                    Toast.makeText(getApplicationContext(),"Favourite set to true",Toast.LENGTH_SHORT).show();
                    //== H.3.1 Dodaję  dane, kóre chcę zapisać w mojej bazie danych.
                    //== H.3.1 Dane pobierzemy z zdefiniowanych zmiennych u góry (dwie poniższe linie)
                    MovieEntryClass movieEntry = new MovieEntryClass(title, photoid, overview, releaseDate, rating,voteEverage
                            , trailerUrl, reviewUrl);
                    movieDb.movieDao().insertMovies(movieEntry);
                    return;
                }
                if(favouriteClicked == true){
                    favouriteClicked = false;
                    mFavouriteImageView.setImageResource(R.drawable.outline_favorite_border_black_24);
             //       Toast.makeText(getApplicationContext(),"Favourite set to false",Toast.LENGTH_LONG).show();
                    //== H.3.2 Usuwamy film z bazy tak jak H.3.1 jeśłi zostało zaznaczone że nie jest już favourite.
               //     MovieEntryClass movieEntry = new MovieEntryClass(title, photoid, overview, releaseDate, rating,voteEverage
                 //           , trailerUrl, reviewUrl);
                  //  movieDb.movieDao().deleteMovies(movieEntry);
                    return;
                }
            }
        });

        mTrailerEmptyState = findViewById(R.id.emptyStateDetailActTextV);

        trailerButton.setChecked(true);

        dataUrl = trailerUrl;

        ConnectivityManager connManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);

        NetworkInfo networkInfo = connManager.getActiveNetworkInfo();

        if(networkInfo != null && networkInfo.isConnected()){

            Log.e("++++++++++TRAILERS RADIO BUTTON++++++++","Enteret to Trailers Radio Button");
            LoaderManager loaderManagerTrailers = getLoaderManager();
            loaderManagerTrailers.initLoader(TRAILER_LOADER_ID,null, DetailActivity.this);
            HAS_IMAGE = true;
        } else {
            View loadingLindicator =findViewById(R.id.detailaActLoadingInd);
            loadingLindicator.setVisibility(View.GONE);
            mTrailerEmptyState.setText(R.string.emptyStateStr);
        }

        dataDetailActRadioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            int checkedRadioButton = dataDetailActRadioGroup.getCheckedRadioButtonId();
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedRadioButton) {
                if(checkedRadioButton == R.id.trailersRadioButDetailActivity){
                    dataUrl = trailerUrl;
                    HAS_IMAGE = true;
                    LoaderManager loaderManagerTrailers = getLoaderManager();
                    loaderManagerTrailers.initLoader(TRAILER_LOADER_ID, null, DetailActivity.this);
                    downloadingData(HAS_IMAGE);
                }
                if(checkedRadioButton == R.id.reviewsRadioButDetailActivity){
                    dataUrl = reviewUrl;
                    HAS_IMAGE = false;
                    if(networkInfo != null && networkInfo.isConnected()){
                        LoaderManager loaderManagerReviews = getLoaderManager();
                        loaderManagerReviews.initLoader(REVIEW_LOADER_ID,null, DetailActivity.this);
                        downloadingData(HAS_IMAGE);
                    }else{
                        View loadingIndicator = findViewById(R.id.loadingIndicator);
                        loadingIndicator.setVisibility(View.GONE);
                        mTrailerEmptyState.setText(R.string.noInternetStr);
                    }
                }
            }

        });
        downloadingData(HAS_IMAGE);
    }

    @NonNull
    @Override
    public Loader<List<ReviewTrailerClass>> onCreateLoader(int id, Bundle args) {
        String urlString = dataUrl;
        return new ReviewTrailerLoaderClass(this, urlString);
    }
    @Override
    public void onLoadFinished(Loader<List<ReviewTrailerClass>> loader, List<ReviewTrailerClass> data) {
        View loadingIndicator = findViewById(R.id.detailaActLoadingInd);
        loadingIndicator.setVisibility(View.GONE);
        reviewTrailers.clear();
        if(data != null && !data.isEmpty()){
            reviewTrailers.addAll(data);
            Log.e("onLoadFinished","++++++++++++++++ Enter to onLoadFinished++++++++++++");
        }else{

            mTrailerEmptyState.setText(R.string.emptyStateStr);

            mTrailerEmptyState.setVisibility(View.VISIBLE);

            mRecyclerView.setVisibility(View.GONE);
        }
        mReviewTrailerAdapter.notifyDataSetChanged();
    }

    @Override
    public void onLoaderReset(Loader<List<ReviewTrailerClass>> loader) { reviewTrailers.clear();}

    @Override
    public void onListItemClick(int clickedPosition, ReviewTrailerClass clickedTrailer) {
        String currentTrailerUrl = clickedTrailer.getmTrailerReviewLink();

        if(HAS_IMAGE == true) {
            Intent webIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(currentTrailerUrl));
            Intent appIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("vnd.youtube://" + clickedTrailer.getmKeyAuthor()));
            try {
                this.startActivity(appIntent);
            } catch (ActivityNotFoundException e) {
                this.startActivity(webIntent);
            }
        }else{
            Intent webIntentReview = new Intent(Intent.ACTION_VIEW,Uri.parse(currentTrailerUrl));
            this.startActivity(webIntentReview);
        }

    }


    public void downloadingData(boolean checkImage){
        mTrailerListItemNo = reviewTrailers.size();
        mRecyclerView = (RecyclerView) findViewById(R.id.recycleViewTrialers);
        GridLayoutManager layoutManager = new GridLayoutManager(this,1);
        mRecyclerView.setLayoutManager(layoutManager);
        mRecyclerView.setHasFixedSize(true);
        mReviewTrailerAdapter = new ReviewTrailerAdapter(this, reviewTrailers, mTrailerListItemNo,this, checkImage);
        mRecyclerView.setAdapter(mReviewTrailerAdapter);
    }
}