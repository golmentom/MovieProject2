package com.example.movieprojectstage2_2021_10_18vesrion5;

import androidx.room.Entity;
import androidx.room.Ignore;
import androidx.room.PrimaryKey;

//== D.0 Utworzyliśmy sobie klasę MovieEntryClass
// ==D.1 Dodajemy adnotacje @Entity dzięi czemu zaczynamy tworzyć room (poniżej)
//== D.1 Dodajemy też tableName w celu zmiany nazwy tabeli bazy danych  z domyslnej
@Entity(tableName = "moviesTable")
public class MovieEntryClass {
    //==D.2 Dodajemy elementy tablicy , którą chcemy wypełniać.
    @PrimaryKey(autoGenerate = true)
    private int id;
    private String title;
    private String poster;
    private String overview;
    private String releaseDate;
    private String rating;
    private String voteEverage;
   private  String traierUrl;
    private String reviewUrl;
    //== D.2.1 Dodatkowo dodajemy zmienną isFavourite, która będzie przechowywać
    //== D.2.1 informację, że dany film jest dodany do  ulubionych.
    boolean isFavourite;

    //== D.3 Dodajemy Pierwszy  konstruktor z adnotacją ignore.
   @Ignore
    public MovieEntryClass(String title, String poster, String overview, String releaseDate, String rating, String voteEverage, String trailerUrl, String reviewUrl){
        this.title = title;
        this.poster = poster;
        this.overview = overview;
        this.releaseDate = releaseDate;
        this.rating = rating;
        this.voteEverage = voteEverage;
        this.traierUrl = trailerUrl;
        this.reviewUrl = reviewUrl;
    }
    public MovieEntryClass(int id, String title, String poster, String overview, String releaseDate, String rating, String voteEverage, String trailerUrl, String reviewUrl){
        this.id = id;
        this.title = title;
        this.poster = poster;
        this.overview = overview;
        this.releaseDate = releaseDate;
        this.rating = rating;
        this.voteEverage = voteEverage;
        this.traierUrl = trailerUrl;
        this.reviewUrl = reviewUrl;
    }
//
public int getId(){return id;}
public String getTitle(){return title;}
public String getPoster(){return poster;}
public String getOverview(){return overview;}
public String getReleaseDate(){return releaseDate;}
public String getRating(){return rating;}
public String getVoteEverage(){return voteEverage;}
public String getTraierUrl(){return traierUrl;}
public String  getReviewUrl(){return reviewUrl;}
public void setId(int id){this.id = id;}
public void setTitle(String title){this.title = title;}
public void setPoster(String poster){this.poster = poster;}
public void setOverview(String overview){this.overview = overview;}
public void setReleaseDate(String releaseDate){this.releaseDate =releaseDate;}
public void setRating(String rating){this.rating = rating;}
public void setVoteEverage(String voteEverage){this.voteEverage = voteEverage;}
public void setTraierUrl(String traierUrl){this.traierUrl = traierUrl;}
public void setReviewUrl(String reviewUrl){this.reviewUrl = reviewUrl;}
}
